let currentPage = 1;
const totalPages = 5;

function go(n) {
  if (n < totalPages) currentPage = n + 1;
  showPage(currentPage);
}

function showPage(n) {
  for (let i = 1; i <= totalPages; i++) {
    const page = document.getElementById('p' + i);
    if (i === n) page.classList.add('active');
    else page.classList.remove('active');
  }

  if(n === 4) typeBirthdayText();       // หน้า 4: พิมทีละตัว + หัวใจ
  if(n === 5) showPhotosWithHearts();   // หน้า 5: รูป+หัวใจ
}

// -------- หน้า 4 : พิมข้อความทีละตัว + หัวใจ --------
const birthdayText = 
"สุขสันต์วันเกิดนะเธอ 🎉\n" +
"ขอให้เธอมีความสุขมากกกกกกก ๆ\n" +
"ร่างกายแข็งแรง\n" +
"คิดสิ่งใดก็ขอให้สมปรารถนา ✨\n" +
"ตั้งใจเรียนด้วยนะ\n" +
"ขอให้ไม่ติดเอฟ 😉\n" +
"เค้าจะอยู่เป็นกำลังใจให้เธอในทุก ๆ วันเลยนะ\n" +
"จุ๊บ ๆ 💖";

function typeBirthdayText() {
  const wordText = document.getElementById('wordText');
  wordText.textContent = "";
  let i = 0;

  function type() {
    if (i < birthdayText.length) {
      wordText.textContent += birthdayText[i];

      // สร้างหัวใจสุ่มเล็ก ๆ ทุก 5 ตัวอักษร
      if (i % 5 === 0) createHeart(wordText, true);

      i++;
      setTimeout(type, 80); // พิมพ์ช้าๆ เหมือนกำลังพิม
    }
  }

  type();
}

// -------- หน้า 5 : รูป + หลายหัวใจลอย --------
const photos = document.querySelectorAll('#p5 .photo');

function showPhotosWithHearts() {
  photos.forEach((photo, i) => {
    setTimeout(() => {
      photo.style.opacity = 1;

      for(let j=0;j<4;j++){
        createHeart(photo, false);
      }

    }, i * 1000);
  });
}

// -------- สร้างหัวใจลอย --------
function createHeart(element, smallOffset) {
  const cardRect = document.querySelector('.card').getBoundingClientRect();
  const rect = element.getBoundingClientRect();

  const heart = document.createElement('div');
  heart.className = 'heart';
  heart.textContent = '💓';

  let offsetX = smallOffset ? Math.random()*20-10 : Math.random()*50-25;
  let offsetY = smallOffset ? Math.random()*20-10 : Math.random()*50-25;

  heart.style.left = (rect.left - cardRect.left + rect.width/2 + offsetX) + 'px';
  heart.style.top = (rect.top - cardRect.top + offsetY) + 'px';

  document.querySelector('.card').appendChild(heart);

  setTimeout(() => {
    heart.style.transform = `translateY(-150px) rotate(${Math.random()*360}deg)`;
    heart.style.opacity = 0;
  }, 50);

  setTimeout(() => heart.remove(), 2500);
}